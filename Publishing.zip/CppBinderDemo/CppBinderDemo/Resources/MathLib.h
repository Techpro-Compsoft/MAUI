// MathLib.h
#ifndef MATHLIB_H
#define MATHLIB_H

extern "C" {
    int Add(int a, int b);
}

#endif // ADDWRAPPER_H