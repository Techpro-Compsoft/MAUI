// MathLib.h
#ifndef MATHLIB_H
#define MATHLIB_H

class MathLib {
public:
    static int Add(int a, int b);
};

#endif // MATHLIB_H
