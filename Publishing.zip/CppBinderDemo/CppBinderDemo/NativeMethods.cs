﻿using System.Runtime.InteropServices;

namespace CppBinderDemo;

public static class NativeMethods
{
    private const string LIBRARY_NAME = "__Internal";  // Use "__Internal" when linking a static library

    [DllImport(LIBRARY_NAME, EntryPoint = "Add")]
    public static extern int Add(int a, int b);
}
