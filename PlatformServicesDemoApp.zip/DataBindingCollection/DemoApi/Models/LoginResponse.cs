﻿namespace DemoApi.Models;

public class LoginResponse
{
    public bool IsAuthenticated { get; set; }
    public string Role { get; set; }
}