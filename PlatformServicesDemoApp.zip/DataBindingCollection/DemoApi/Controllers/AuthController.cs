﻿using DemoApi.Models;
using Microsoft.AspNetCore.Mvc;

namespace DemoApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        [HttpPost]
        public LoginResponse Login(LoginRequest request)
        {
            if (request.Email == "admin@gmail.com" && request.Password == "admin")
                return new LoginResponse() { IsAuthenticated = true, Role = "Admin" };
            if (request.Email == "user@gmail.com" && request.Password == "user")
                return new LoginResponse() { IsAuthenticated = true, Role = "User" };
            return new LoginResponse() { IsAuthenticated = false };
        }
    }
}
