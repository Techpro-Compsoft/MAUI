using DataBindingCollection.ViewModels;

namespace DataBindingCollection.Views;

public partial class LoginPage : ContentPage
{
	public LoginPage(LoginViewModel model)
	{
		InitializeComponent();
        this.BindingContext = model;
    }
}