﻿using DataBindingCollection.ViewModels;

namespace DataBindingCollection
{
    public partial class MainPage : ContentPage
    {
        int count = 0;

        public MainPage()
        {
            InitializeComponent();
            var viewModel= new UserViewModel();
            viewModel.AnimationTriggeredEvent += ViewModel_AnimationTriggeredEvent;
            this.BindingContext = viewModel;

        }

        private void ViewModel_AnimationTriggeredEvent(object? sender, EventArgs e)
        {
            NameLabel.TranslationX = -500;
            NameEntry.TranslationX = -500;
            var animation = new Animation();
            animation.Add(0,0.2, new Animation(a=> NameLabel.TranslationX = a, -500,0,Easing.SinInOut));
            animation.Add(0.1,0.3, new Animation(a=> NameEntry.TranslationX = a, -500,0,Easing.SinInOut));
            animation.Commit(this,"SlideInAnimation", 16,1000);
        }
    }

}
