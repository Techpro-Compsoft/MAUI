﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using DataBindingCollection.Models;

namespace DataBindingCollection.ViewModels
{
    public class UserViewModel : INotifyPropertyChanged
    {
        private ObservableCollection<User> _users;
        private string _name;
        private int _age;
        private string _email;

        public UserViewModel()
        {
            Users =
            [
                new User() { Name = "User 1", Age = 30, Email = "User1@gmail.com" },
                new User() { Name = "User 2", Age = 34, Email = "User2@gmail.com" },
                new User() { Name = "User 3", Age = 35, Email = "User3@gmail.com" }
            ];
            AddUserCommand = new Command(OnAddUser);
        }

        public event EventHandler AnimationTriggeredEvent;
        private void OnAddUser()
        {
            var user = new User() { Name = this.Name, Age = Age, Email = Email };
            Users.Add((user));

            Name = Email = string.Empty;
            Age = 0;
            AnimationTriggeredEvent?.Invoke(this, EventArgs.Empty);
        }

        public Command AddUserCommand { get; }
        public string Name
        {
            get => _name;
            set
            {
                if (value == _name) return;
                _name = value;
                OnPropertyChanged();
            }
        }

        public int Age
        {
            get => _age;
            set
            {
                if (value == _age) return;
                _age = value;
                OnPropertyChanged();
            }
        }

        public string Email
        {
            get => _email;
            set
            {
                if (value == _email) return;
                _email = value;
                OnPropertyChanged();
            }
        }

        public ObservableCollection<User> Users
        {
            get => _users;
            set
            {
                _users = value;
                OnPropertyChanged();
            } 
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

    }
}
