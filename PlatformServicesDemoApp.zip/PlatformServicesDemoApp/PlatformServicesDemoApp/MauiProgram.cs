﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Maui.Controls.Hosting;
using Microsoft.Maui.Hosting;

using PlatformServicesDemoApp.Services;

namespace PlatformServicesDemoApp
{
    public static class MauiProgram
    {
        public static MauiApp CreateMauiApp()
        {
            var builder = MauiApp.CreateBuilder();
            builder
                .UseMauiApp<App>()
                .ConfigureFonts(fonts =>
                {
                    fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                    fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
                });
#if IOS
                        builder.Services.AddSingleton<IBatteryService,PlatformServicesDemoApp.Platforms.iOS.BatteryService>();
#endif

#if ANDROID
            builder.Services.AddSingleton<IBatteryService, PlatformServicesDemoApp.Platforms.Android.BatteryService>();
#endif

#if WINDOWS
            builder.Services.AddSingleton<IBatteryService,PlatformServicesDemoApp.Platforms.Windows.BatteryService>();
#endif
#if DEBUG
            builder.Logging.AddDebug();
#endif

            return builder.Build();
        }
    }
}
