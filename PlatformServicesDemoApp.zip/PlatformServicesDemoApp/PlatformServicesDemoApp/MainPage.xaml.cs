﻿using PlatformServicesDemoApp.Services;

namespace PlatformServicesDemoApp
{
    public partial class MainPage : ContentPage
    {
        private readonly IBatteryService _batteryService;

        public static readonly BindableProperty BatteryLevelProperty =
            BindableProperty.Create(nameof(BatteryLevel),typeof(int),typeof(MainPage),0);


        public int BatteryLevel
        {
            get => (int)GetValue(BatteryLevelProperty);
            set => SetValue(BatteryLevelProperty, value);
        }

        public MainPage(IBatteryService batteryService)
        {
            _batteryService = batteryService;
            InitializeComponent();
            BatteryLevel = batteryService.GetBatteryLevel();
            this.BindingContext = this;
        }

    }

}
