﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PlatformServicesDemoApp.Services;

namespace PlatformServicesDemoApp.Platforms.Windows
{
    internal class BatteryService : IBatteryService
    {
        public int GetBatteryLevel()
        {
            return (int)(Battery.ChargeLevel * 100);
        }
    }
}
