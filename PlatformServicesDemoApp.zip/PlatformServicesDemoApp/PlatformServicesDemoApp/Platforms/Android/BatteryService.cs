﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Android.Content;
using Android.OS;
using PlatformServicesDemoApp.Services;
using Application = Android.App.Application;

namespace PlatformServicesDemoApp.Platforms.Android
{
    internal class BatteryService : IBatteryService
    {
        public int GetBatteryLevel()
        {
            // Access Android-specific APIs to get battery level
            var filter = new IntentFilter(Intent.ActionBatteryChanged);
            var batteryStatus = Application.Context.RegisterReceiver(null, filter);
            int level = batteryStatus.GetIntExtra(BatteryManager.ExtraLevel, -1);
            int scale = batteryStatus.GetIntExtra(BatteryManager.ExtraScale, -1);
            return (int)(level * 100 / (float)scale);
        }
    }
}
