﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PlatformServicesDemoApp.Services;
using UIKit;

namespace PlatformServicesDemoApp.Platforms.iOS
{
    internal class BatteryService : IBatteryService
    {
        public int GetBatteryLevel()
        {
            UIDevice.CurrentDevice.BatteryMonitoringEnabled = true;
            return (int)(UIDevice.CurrentDevice.BatteryLevel * 100);
        }
    }
}
