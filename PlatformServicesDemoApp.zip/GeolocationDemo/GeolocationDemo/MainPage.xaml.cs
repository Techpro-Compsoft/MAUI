﻿using System.Diagnostics;
using GeolocationDemo.Services;

namespace GeolocationDemo
{
    public partial class MainPage : ContentPage
    {
        int count = 0;

        public static readonly BindableProperty BatteryLevelProperty =
             BindableProperty.Create(nameof(BatteryLevel), typeof(int), typeof(MainPage), 0);
        public MainPage(IBatteryService batteryService)
        {
            InitializeComponent();
            BatteryLevel = GetBatteryLevel(batteryService);
            this.BindingContext = this;
        }

        public int BatteryLevel
        {
            get => (int)GetValue(BatteryLevelProperty);
            set => SetValue(BatteryLevelProperty, value);
        }

        private async void OnGetLocationClicked(object sender, EventArgs e)
        {
            try
            {
                // Request location permission
                var status = await Permissions.RequestAsync<Permissions.LocationWhenInUse>();
                if (status != PermissionStatus.Granted)
                {
                    await DisplayAlert("Permission Denied", "Location permission is required to get your location.",
                        "OK");
                    return;
                }

                // Get the current location
                var location = await Geolocation.GetLocationAsync(new GeolocationRequest
                {
                    DesiredAccuracy = GeolocationAccuracy.Medium,
                    Timeout = TimeSpan.FromSeconds(30)
                });

                if (location != null)
                {
                    // Display the location coordinates
                    await DisplayAlert("Location",
                        $"Latitude: {location.Latitude}, Longitude: {location.Longitude}, Altitude: {location.Altitude}",
                        "OK");
                }
                else
                {
                    await DisplayAlert("Error", "Unable to get location.", "OK");
                }
            }
            catch (FeatureNotSupportedException)
            {
                await DisplayAlert("Error", "GPS is not supported on this device.", "OK");
            }
            catch (PermissionException)
            {
                await DisplayAlert("Error", "Location permission is required.", "OK");
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", $"An error occurred: {ex.Message}", "OK");
            }
        }

        private async void OnTakePhotoClicked(object sender, EventArgs e)
        {
            try
            {
                // Request camera permission
                var status = await Permissions.RequestAsync<Permissions.Camera>();
                if (status != PermissionStatus.Granted)
                {
                    await DisplayAlert("Permission Denied", "Camera permission is required to take photos.", "OK");
                    return;
                }

                // Take a photo
                var photo = await MediaPicker.CapturePhotoAsync();
                if (photo != null)
                {
                    // Save the photo to a temporary file
                    var stream = await photo.OpenReadAsync();
                    var imageSource = ImageSource.FromStream(() => stream);

                    // Display the photo in an Image control
                    CapturedImage.Source = imageSource;
                }
            }
            catch (FeatureNotSupportedException)
            {
                await DisplayAlert("Error", "Camera is not supported on this device.", "OK");
            }
            catch (PermissionException)
            {
                await DisplayAlert("Error", "Camera permission is required.", "OK");
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", $"An error occurred: {ex.Message}", "OK");
            }
        }
       
            private void OnStartClicked(object sender, EventArgs e)
            {
                try
                {
                    // Check if the accelerometer is supported
                    if (Accelerometer.IsSupported)
                    {
                        // Set the sensor speed (options: Default, UI, Game, Fastest)
                        Accelerometer.ReadingChanged += Accelerometer_ReadingChanged;
                        Accelerometer.Start(SensorSpeed.UI);
                    }
                    else
                    {
                        DisplayAlert("Error", "Accelerometer is not supported on this device.", "OK");
                    }
                }
                catch (Exception ex)
                {
                    DisplayAlert("Error", $"An error occurred: {ex.Message}", "OK");
                }
            }

            private void OnStopClicked(object sender, EventArgs e)
            {
                try
                {
                    if (Accelerometer.IsSupported)
                    {
                        Accelerometer.Stop();
                        Accelerometer.ReadingChanged -= Accelerometer_ReadingChanged;
                        Debug.WriteLine("Accelerometer stopped.");
                    }
                }
                catch (Exception ex)
                {
                    DisplayAlert("Error", $"An error occurred: {ex.Message}", "OK");
                }
            }

            private void Accelerometer_ReadingChanged(object sender, AccelerometerChangedEventArgs e)
            {
                // Get the accelerometer data
                var data = e.Reading;

                // Update the UI with the accelerometer data
                Dispatcher.Dispatch(() =>
                {
                    XLabel.Text = $"X: {data.Acceleration.X:F2}";
                    YLabel.Text = $"Y: {data.Acceleration.Y:F2}";
                    ZLabel.Text = $"Z: {data.Acceleration.Z:F2}";
                });

                // Log the data to the debug console
                Debug.WriteLine(
                    $"X: {data.Acceleration.X:F2}, Y: {data.Acceleration.Y:F2}, Z: {data.Acceleration.Z:F2}");
            }
            public int GetBatteryLevel(IBatteryService batteryService)
            {
                //var batteryService = DependencyService.Get<IBatteryService>();
                return batteryService.GetBatteryLevel();
            }
    }
    }



