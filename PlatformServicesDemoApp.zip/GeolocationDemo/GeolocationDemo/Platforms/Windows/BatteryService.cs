﻿using GeolocationDemo.Services;

namespace GeolocationDemo.Platforms.Windows
{
        public class BatteryService : IBatteryService
        {
            public int GetBatteryLevel()
            {
                return (int)(Battery.ChargeLevel * 100);
            }
    }
}
