﻿using GeolocationDemo.Services;
using UIKit;

namespace GeolocationDemo.Platforms.iOS
{
        public class BatteryService : IBatteryService
        {
            public int GetBatteryLevel()
            {
                // Access iOS-specific APIs to get battery level
                UIDevice.CurrentDevice.BatteryMonitoringEnabled = true;
                return (int)(UIDevice.CurrentDevice.BatteryLevel * 100);
            }
    }
}
