﻿using DataBoundApp.ViewModels;

namespace DataBoundApp
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();

            // Set the BindingContext to an instance of the ViewModel
            BindingContext = new UserViewModel();

            // Subscribe to the animation event
            if (BindingContext is UserViewModel viewModel)
            {
                viewModel.AnimationTriggered += OnAnimationTriggered;
            }

            // Trigger the initial slide-in animation
            AnimateFormControls();
        }

        private void OnAnimationTriggered(object sender, EventArgs e)
        {
            // Trigger the slide-in animation when a new user is added
            AnimateFormControls();
        }

        private void AnimateFormControls()
        {
            // Slide-in animation for form controls
            NameLabel.TranslationX = -500;
            NameEntry.TranslationX = -500;
            EmailLabel.TranslationX = -500;
            EmailEntry.TranslationX = -500;
            AgeLabel.TranslationX = -500;
            AgeEntry.TranslationX = -500;

            var animation = new Animation();

            animation.Add(0, 0.2, new Animation(v => NameLabel.TranslationX = v, -500, 0, Easing.SinOut));
            animation.Add(0.1, 0.3, new Animation(v => NameEntry.TranslationX = v, -500, 0, Easing.SinOut));
            animation.Add(0.2, 0.4, new Animation(v => EmailLabel.TranslationX = v, -500, 0, Easing.SinOut));
            animation.Add(0.3, 0.5, new Animation(v => EmailEntry.TranslationX = v, -500, 0, Easing.SinOut));
            animation.Add(0.4, 0.6, new Animation(v => AgeLabel.TranslationX = v, -500, 0, Easing.SinOut));
            animation.Add(0.5, 0.7, new Animation(v => AgeEntry.TranslationX = v, -500, 0, Easing.SinOut));

            animation.Commit(this, "SlideInAnimation", 16, 1000);
        }
    }

}
