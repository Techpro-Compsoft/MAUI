﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using DataBoundApp.Models;
using Microsoft.Maui.Controls;


namespace DataBoundApp.ViewModels
{
    public class UserViewModel : INotifyPropertyChanged
    {
        private ObservableCollection<User> _users;
        private string _name;
        private string _email;
        private int _age;

        public UserViewModel()
        {
            _users = new ObservableCollection<User>();
            AddUserCommand = new Command(OnAddUser);
            AddUserWithAnimationCommand = new Command(OnAddUserWithAnimation);
        }

        public ObservableCollection<User> Users
        {
            get => _users;
            set
            {
                _users = value;
                OnPropertyChanged();
            }
        }

        public string Name
        {
            get => _name;
            set
            {
                _name = value;
                OnPropertyChanged();
            }
        }

        public string Email
        {
            get => _email;
            set
            {
                _email = value;
                OnPropertyChanged();
            }
        }

        public int Age
        {
            get => _age;
            set
            {
                _age = value;
                OnPropertyChanged();
            }
        }

        public Command AddUserCommand { get; }

        private void OnAddUser()
        {
            if (!string.IsNullOrEmpty(Name) && !string.IsNullOrEmpty(Email) && Age > 0)
            {
                var user = new User { Name = Name, Email = Email, Age = Age };
                Users.Add(user);

                // Clear the form fields
                Name = string.Empty;
                Email = string.Empty;
                Age = 0;
            }
        }
        public Command AddUserWithAnimationCommand { get; }

        private void OnAddUserWithAnimation()
        {
            if (!string.IsNullOrEmpty(Name) && !string.IsNullOrEmpty(Email) && Age > 0)
            {
                var user = new User { Name = Name, Email = Email, Age = Age };
                Users.Add(user);

                // Clear the form fields
                Name = string.Empty;
                Email = string.Empty;
                Age = 0;

                // Notify the View to trigger the animation
                AnimationTriggered?.Invoke(this, EventArgs.Empty);
            }
        }

        public event EventHandler AnimationTriggered;
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
