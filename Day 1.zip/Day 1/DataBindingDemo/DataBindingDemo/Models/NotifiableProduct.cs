﻿using System.ComponentModel;

namespace DataBindingDemo.Models
{
    public class NotifiableProduct : INotifyPropertyChanged
    {
        private int id;
        private string name;
        private string description;
        private double price;
        private string imageUrl;
        private DateTime offerEndDate;
        private bool isAvailable;


        public int Id
        {
            get => id;
            set
            {
                id = value;
                RaisePropertyChanged(nameof(Id));

            }
        }

        public string Name
        {
            get => name;
            set
            {
                name = value;
                RaisePropertyChanged(nameof(Name));
            }
        }

        public string Description
        {
            get => description;
            set
            {
                description = value;
                RaisePropertyChanged(nameof(Description));
            }
        }

        public double Price
        {
            get => price;
            set
            {
                price = value;
                RaisePropertyChanged(nameof(Price));
            }
        }

        public string ImageUrl
        {
            get => imageUrl;
            set
            {
                imageUrl = value;
                RaisePropertyChanged(nameof(ImageUrl));
            }
        }

        public DateTime OfferEndDate
        {
            get => offerEndDate;
            set
            {
                offerEndDate = value;
                RaisePropertyChanged(nameof(OfferEndDate));
            }
        }

        public bool IsAvailable { get => isAvailable;
            set
            {
                isAvailable = value; RaisePropertyChanged(nameof(IsAvailable));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public void RaisePropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
