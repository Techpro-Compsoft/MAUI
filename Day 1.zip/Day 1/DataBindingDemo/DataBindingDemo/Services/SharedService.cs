﻿namespace DataBindingDemo.Services
{
    public class SharedService : ISharedService
    {
        private Dictionary<string, object> Dictionary { get; set; } = new Dictionary<string, object>();

        public void Add<T>(string key, T value) where T : class
        {
            if (Dictionary.ContainsKey(key))
            {
                Dictionary[key] = value;
            }
            else
            {
                Dictionary.Add(key, value);
            }
        }

        public T GetValue<T>(string key) where T : class
        {
            if (Dictionary.ContainsKey(key))
            {
                return Dictionary[key] as T;
            }
            return null;
        }
    }
}
