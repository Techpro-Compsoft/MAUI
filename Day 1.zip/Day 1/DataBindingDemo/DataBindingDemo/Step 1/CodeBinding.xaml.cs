namespace DataBindingDemo;

public partial class CodeBinding : ContentPage
{
    private readonly BindableProperty SCount = BindableProperty.Create(nameof(StudentCount), typeof(int), typeof(MainPage), 0);

    public int StudentCount
    {
        get => (int)GetValue(SCount);
        set => SetValue(SCount, value);
    }

    public int Test { get; set; }

    public CodeBinding()
	{
		InitializeComponent();
        // Set the BindingContext to this code-behind
        BindingContext = this;
    }

    private void Button_Clicked(object sender, EventArgs e)
    {
        StudentCount++;
    }

    private void Button_Clicked_1(object sender, EventArgs e)
    {
        Test++;
    }
}