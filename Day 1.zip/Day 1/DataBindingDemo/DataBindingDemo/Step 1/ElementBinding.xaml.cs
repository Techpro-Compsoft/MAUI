namespace DataBindingDemo;

public partial class ElementBinding : ContentPage
{
	public ElementBinding()
	{
		InitializeComponent();
        label.BindingContext = slider;
        label.SetBinding(Label.RotationProperty, "Value");
    }
}