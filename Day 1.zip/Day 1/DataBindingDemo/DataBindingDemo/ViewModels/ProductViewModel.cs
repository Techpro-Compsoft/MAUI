﻿using DataBindingDemo.Models;
using DataBindingDemo.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using DataBindingDemo.Services;

namespace DataBindingDemo.ViewModels
{
    public class ProductViewModel : INotifyPropertyChanged
    {
        public ICommand SaveCommand { get;private set; }
        public ICommand ResetCommand { get;private set; }
        public ICommand NavigateCommand { get;private set; }
        private NotifiableProduct product;

        public ProductViewModel()
        {
            Product = new NotifiableProduct();
            SaveCommand = new Command(Save, CanSave);
            ResetCommand = new Command(Reset, CanReset);
            NavigateCommand = new Command(Navigate, (o) => true);
        }

        private void Navigate(object obj)
        {
            var productDetails = new ProductDetails();
            var productDetailsViewModel = ServiceHelper.Current.GetService<ProductDetailsViewModel>();
            productDetailsViewModel.Name = "This is some test data";
            productDetails.BindingContext = productDetailsViewModel;
            Shell.Current.Navigation.PushAsync(productDetails) ;
        }

        private bool CanReset(object arg)
        {
            return true;
        }

        private void Reset(object obj)
        {
            Product = new NotifiableProduct();
        }

        private bool CanSave(object arg)
        {
            return true;
        }

        private void Save(object obj)
        {
            
            //Logic to Save
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        public NotifiableProduct Product
        {
            get => product;
            set
            {
                product = value;
                RaisePropertyChanged(nameof(Product));
            }
        }

        public void RaisePropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
