﻿using DataBindingDemo.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataBindingDemo.ViewModels
{
    public class ProductDetailsViewModel : BaseViewModel
    {
        public string Name
        {
            get => name;
            set
            {
                name = value;
                RaisePropertyChanged(nameof(Name));
            } 
        }

        private readonly ISharedService sharedService;
        private string name;

        public ProductDetailsViewModel(ISharedService sharedService)
        {
            this.sharedService = sharedService;
        }
    }
}
