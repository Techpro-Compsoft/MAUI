namespace DataBindingDemo.Views;

public partial class ProductViewWithViewModel : ContentPage
{
	public ProductViewWithViewModel()
	{
		InitializeComponent();
	}
}