using DataBindingDemo.Models;

namespace DataBindingDemo.Views;

public partial class ProductViewNotifiable : ContentPage
{
	public ProductViewNotifiable()
	{
		InitializeComponent();
        this.BindingContext = new NotifiableProduct()
        {
            Id = 1,
            Description = "Apple Watch.",
            ImageUrl = "https://store.storeimages.cdn-apple.com/1/as-images.apple.com/is/MXM63ref_FV98_VW_34FR+watch-case-44-aluminum-starlight-nc-se_VW_34FR+watch-face-44-aluminum-starlight-se_VW_34FR?wid=5120&hei=3280&bgc=fafafa&trim=1&fmt=p-jpg&qlt=80&.v=QVR6TmZRU2x1RjZIVW5wdDlyenB5RW5TeWJ6QW43NUFnQ2V4cmRFc1VnWURIZXhSOVNUU1hpL1hkOUNjbEVLTCsydHFDU0pvT1BSK2dOS3RYTkxwdzlGNnlaeXQ4NGFKQTAzc0NGeHR2aVp0aE9FQnlrZ00zbUdqcHZKNEpaMWJaS1ZRdWNPS3Q1RURqYVgyaEZJZmtYY0dmQWU1UUhxNENQZVRyQjk5ZnRCcVBpVENpMUluRnVNbld0T1NWSFh2cXlYK1hMV0U1ZW9xcCtlRHF3V3gyUWw1MXVoaC9rQ0tINDRNUEExR2JHRU5mTDhYbjVxRUx5MXNydDUvcjcyYQ",
            OfferEndDate = new DateTime(2025, 2, 10),
            Name = "Apple",
            Price = 22000
        };
    }

    private void SaveProductButton_Clicked(object sender, EventArgs e)
    {
        var product = BindingContext as NotifiableProduct;

        product.Id = 2;
        product.Description = "Apple Watch 2.";
        product.ImageUrl = "https://store.storeimages.cdn-apple.com/1/as-images.apple.com/is/MXM63ref_FV98_VW_34FR+watch-case-44-aluminum-starlight-nc-se_VW_34FR+watch-face-44-aluminum-starlight-se_VW_34FR?wid=5120&hei=3280&bgc=fafafa&trim=1&fmt=p-jpg&qlt=80&.v=QVR6TmZRU2x1RjZIVW5wdDlyenB5RW5TeWJ6QW43NUFnQ2V4cmRFc1VnWURIZXhSOVNUU1hpL1hkOUNjbEVLTCsydHFDU0pvT1BSK2dOS3RYTkxwdzlGNnlaeXQ4NGFKQTAzc0NGeHR2aVp0aE9FQnlrZ00zbUdqcHZKNEpaMWJaS1ZRdWNPS3Q1RURqYVgyaEZJZmtYY0dmQWU1UUhxNENQZVRyQjk5ZnRCcVBpVENpMUluRnVNbld0T1NWSFh2cXlYK1hMV0U1ZW9xcCtlRHF3V3gyUWw1MXVoaC9rQ0tINDRNUEExR2JHRU5mTDhYbjVxRUx5MXNydDUvcjcyYQ";
        product.OfferEndDate = new DateTime(2026, 2, 10);
        product.Name = "Apple watch";
        product.Price = 25080;
    }
    
}