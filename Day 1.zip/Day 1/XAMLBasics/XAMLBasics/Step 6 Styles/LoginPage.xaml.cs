namespace XAMLBasics.Step_6_Styles;

public partial class LoginPage : ContentPage
{
	public LoginPage()
	{
		InitializeComponent();
	}
}