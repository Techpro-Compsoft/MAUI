namespace XAMLBasics.Step_3;

public partial class MoreControlsAndCleanUp : ContentPage
{
    Timer _timer  ;

	public MoreControlsAndCleanUp()
	{
		InitializeComponent();
      
	}
    private void OnSaveButtonClicked(object sender, EventArgs e)
    {

    }

    private void OnDeleteButtonClicked(object sender, EventArgs e)
    {

    }

    private void ContentPage_Loaded(object sender, EventArgs e)
    {
        _timer = new Timer(TimerCallback, null, TimeSpan.Zero, TimeSpan.FromSeconds(1));
    }
    private void TimerCallback(object state)
    {
        Console.WriteLine("Timer running...");
    }

    protected override void OnDisappearing()
    {
        base.OnDisappearing();
        _timer?.Dispose(); // Dispose the timer to avoid leaks
    }

    public void Dispose()
    {
        _timer?.Dispose();
        GC.SuppressFinalize(this); // Optimize GC behavior
    }
}