namespace XAMLBasics.Step_4_Layout_Controls;

public partial class FlexLayout : ContentPage
{
	public FlexLayout()
	{
		InitializeComponent();
	}
}