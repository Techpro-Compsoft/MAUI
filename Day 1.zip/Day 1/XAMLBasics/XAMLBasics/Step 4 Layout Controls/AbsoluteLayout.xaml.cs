namespace XAMLBasics.Step_4_Layout_Controls;

public partial class AbsoluteLayout : ContentPage
{
	public AbsoluteLayout()
	{
		InitializeComponent();
	}
}