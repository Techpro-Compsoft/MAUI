namespace XAMLBasics.Step_4_Layout_Controls;

public partial class GridLayout : ContentPage
{
	public GridLayout()
	{
		InitializeComponent();
	}
}