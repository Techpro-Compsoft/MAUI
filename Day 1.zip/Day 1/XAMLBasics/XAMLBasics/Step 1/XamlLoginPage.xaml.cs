using System.Diagnostics;

namespace XAMLBasics;

public partial class XamlLoginPage : ContentPage
{
	public XamlLoginPage()
	{
		InitializeComponent();
	}

    private void loginButton_Clicked(object sender, EventArgs e)
    {
        Debug.WriteLine("Clicked !");
    }
}