namespace XAMLBasics.Step_5_Pages;

public partial class ContentPageDemo : ContentPage
{
	public ContentPageDemo()
	{
		InitializeComponent();
	}
}