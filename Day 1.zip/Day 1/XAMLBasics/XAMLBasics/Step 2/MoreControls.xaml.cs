namespace XAMLBasics;

public partial class MoreControls : ContentPage
{
	public MoreControls()
	{
		InitializeComponent();
	}

    private void OnSaveButtonClicked(object sender, EventArgs e)
    {

    }

    private void OnDeleteButtonClicked(object sender, EventArgs e)
    {

    }


}