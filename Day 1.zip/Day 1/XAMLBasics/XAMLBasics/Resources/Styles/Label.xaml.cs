namespace XAMLBasics.Resources.Styles;

public partial class Label : ResourceDictionary
{
	public Label()
	{
		InitializeComponent();
	}
}