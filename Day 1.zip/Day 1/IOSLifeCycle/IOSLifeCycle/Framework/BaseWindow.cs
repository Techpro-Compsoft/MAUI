﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IOSLifeCycle.Framework
{
    public class BaseWindow : Window
    {
        public BaseWindow()
        {

        }

        public BaseWindow(Page page) : base(page) 
        {

        }

        protected override void OnCreated()
        {
            base.OnCreated();
        }

        protected override void OnActivated()
        {
            base.OnActivated();
        }

        protected override void OnDeactivated()
        {
            base.OnDeactivated();
        }

        protected override void OnResumed()
        {
            base.OnResumed();
        }

        protected override void OnStopped()
        {
            base.OnStopped();
        }

        protected override void OnDestroying()
        {
            base.OnDestroying();
        }
    }
}
