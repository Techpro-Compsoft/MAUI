﻿using IOSLifeCycle.Framework;

namespace IOSLifeCycle
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();
        }

        protected override Window CreateWindow(IActivationState? activationState)
        {
            //var window = new Window(new AppShell());

            //window.Created += Window_Created;

            //window.Activated += Window_Activated;

            //window.Deactivated += Window_Deactivated;

            //window.Stopped += Window_Stopped;

            //window.Resumed += Window_Resumed;

            //window.Destroying += Window_Destroying;

            var window = new BaseWindow(new AppShell());

            return window;
        }

        private void Window_Destroying(object? sender, EventArgs e)
        {
            Console.WriteLine("Destroying");
        }

        private void Window_Resumed(object? sender, EventArgs e)
        {
            Console.WriteLine("Resumed");
        }

        private void Window_Stopped(object? sender, EventArgs e)
        {
            Console.WriteLine("Stopped");
        }

        private void Window_Activated(object? sender, EventArgs e)
        {
            Console.WriteLine("Activated");
        }

        private void Window_Deactivated(object? sender, EventArgs e)
        {
            Console.WriteLine("Deactivated");
        }

        private void Window_Created(object? sender, EventArgs e)
        {
            Console.WriteLine("Created");
        }
    }
}