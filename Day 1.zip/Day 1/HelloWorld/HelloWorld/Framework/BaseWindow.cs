﻿
namespace HelloWorld.Framework
{
    public class BaseWindow : Window
    {
        public BaseWindow(Page page) : base(page)
        {
        }

        protected override void OnActivated()
        {
            base.OnActivated();
        }

        protected override void OnCreated()
        {
            base.OnCreated();
        }

        protected override void OnDeactivated()
        {
            base.OnDeactivated();
        }

        protected override void OnDestroying()
        {
            base.OnDestroying();
        }

        protected override void OnStopped()
        {
            base.OnStopped();
        }

        protected override void OnResumed()
        {
            base.OnResumed();
        }
        protected override void OnBackgrounding(IPersistedState state)
        {
            base.OnBackgrounding(state);
        }
    }
}
