﻿namespace HelloWorld
{
    public partial class AppShell : Shell
    {
        public AppShell()
        {
            InitializeComponent();
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
        }

        protected override void OnDisappearing() 
        { 
            base.OnDisappearing(); 
        }

    }
}
