﻿using Microsoft.Extensions.Logging;
using Microsoft.Maui.LifecycleEvents;
using System.Diagnostics;

namespace HelloWorld
{
    public static class MauiProgram
    {
        public static MauiApp CreateMauiApp()
        {
            var builder = MauiApp.CreateBuilder();
            builder
                .UseMauiApp<App>()
//                .ConfigureLifecycleEvents(events =>
//                {
//#if ANDROID
//                    events.AddAndroid(android => android.OnStart((activity)=> Debug.WriteLine("OnStart")));
//#endif
//#if IOS
//                    events.AddiOS(ios => ios.OnActivated(app => Debug.WriteLine("OnActivated")));
//#endif
//                })
                .ConfigureFonts(fonts =>
                {
                    fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                    fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
                });

#if DEBUG
    		builder.Logging.AddDebug();
#endif

            return builder.Build();
        }
    }
}
