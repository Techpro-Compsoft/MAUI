﻿using HelloWorld.Framework;

namespace HelloWorld
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();
        }

        protected override Window CreateWindow(IActivationState? activationState)
        {
            return new BaseWindow(new AppShell());
        }
    }
}