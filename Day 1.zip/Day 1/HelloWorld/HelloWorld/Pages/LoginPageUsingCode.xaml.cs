namespace HelloWorld.Pages;

public partial class LoginPageUsingCode : ContentPage
{
	public LoginPageUsingCode()
	{
		VerticalStackLayout layout = new VerticalStackLayout();
		layout.Children.Add(new Label() { Text="Please Login"});
		layout.Children.Add(new Label() { Text = "User Name" });
        layout.Children.Add(new Entry());
		layout.Children.Add(new Label() { Text = "Password" });
		layout.Children.Add(new Entry() { IsPassword = true});
		
		 Button button = new Button();
		button.Clicked += (s, e) => {
		};
		button.Text = "Login";
		layout.Children.Add(button);

		Content = layout;

        //InitializeComponent();

    }
}