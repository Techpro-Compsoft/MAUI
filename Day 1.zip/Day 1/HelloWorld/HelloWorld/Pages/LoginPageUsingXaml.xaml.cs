namespace HelloWorld.Pages;

public partial class LoginPageUsingXaml : ContentPage
{
	public LoginPageUsingXaml()
	{
		InitializeComponent();
	}

    private void btnLogin_Clicked(object sender, EventArgs e)
    {
		//txtUsername.Text
    }
}