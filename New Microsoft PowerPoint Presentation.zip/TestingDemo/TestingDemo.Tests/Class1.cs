﻿namespace TestingDemo.Tests
{
    // All the code in this file is included in all platforms.
    using Moq;
    using Xunit;

    public class MainPageTests
    {
        [Fact]
        public void GetDeviceName_ReturnsDeviceName()
        {
            // Arrange
            var mockService = new Mock<IDeviceInfoService>();

#if IOS // Conditional compilation for iOS
        mockService.Setup(x => x.GetDeviceName()).Returns("Mocked iOS Device");
#elif ANDROID // Conditional compilation for Android
            mockService.Setup(x => x.GetDeviceName()).Returns("Mocked Android Device");
#else // Default (if needed)
        mockService.Setup(x => x.GetDeviceName()).Returns("Mocked Device");
#endif

            var mainPage = new MainPage(mockService.Object);

            // Act
           // mainPage.Button..GetDeviceName_Clicked(null, null);

            // Assert
           // Assert.Equal("Mocked Device", mainPage.DeviceNameLabel.Text); // Update expected value if needed

        }
    }
}
