﻿//// DeviceInfoApp.UITests/MainPageUITests.cs
//using Microsoft.Maui.Controls.UITesting;
//using Xunit;

//public class MainPageUITests
//{
//    private readonly IApp _app;

//    public MainPageUITests()
//    {
//        _app = AppInitializer.StartApp(); // Configure for iOS
//    }

//    [Fact]
//    public void ClickingButton_DisplaysDeviceName()
//    {
//        // Arrange
//        _app.WaitForElement("Get Device Name"); // Wait for the button

//        // Act
//        _app.Tap("Get Device Name");

//        // Assert
//        _app.WaitForElement("DeviceNameLabel"); // Wait for the label
//        var labelText = _app.Query("DeviceNameLabel").Text();
//        Assert.NotEmpty(labelText); // Check if the label is not empty (device name should be there)
//    }
//}