﻿using Moq;
using TestingDemo;

namespace TestingDmo.Tests
{
    public class MainPageTests
    {
        [Fact]
        public void GetDeviceName_ReturnsDeviceName()
        {
            // Arrange
            var mockService = new Mock<IDeviceInfoService>();
            mockService.Setup(x => x.GetDeviceName()).Returns("Test Device");

            var mainPage = new TestingDemo.MainPage(mockService.Object);
            mainPage._deviceInfoService.GetDeviceName();
            // Act
            mainPage.GetDeviceName_Clicked(null, null);

            // Assert
           // Assert.Equal("Test Device", mainPage.DeviceNameLabel.Text); // Check the label text
        }
    }
}
