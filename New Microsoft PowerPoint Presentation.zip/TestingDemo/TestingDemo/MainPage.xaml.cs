﻿namespace TestingDemo
{
    public partial class MainPage : ContentPage
    {
        internal readonly IDeviceInfoService _deviceInfoService;

        public MainPage(IDeviceInfoService deviceInfoService)
        {
            InitializeComponent();
            _deviceInfoService = deviceInfoService;
        }

        internal void GetDeviceName_Clicked(object sender, EventArgs e)
        {
            DeviceNameLabel.Text = _deviceInfoService.GetDeviceName();
        }
    }
}


