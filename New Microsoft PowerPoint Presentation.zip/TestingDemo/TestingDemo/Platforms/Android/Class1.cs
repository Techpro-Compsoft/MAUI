﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Maui.Controls.PlatformConfiguration;

namespace TestingDemo.Platforms.Android
{
    public class AndroidDeviceInfoService : IDeviceInfoService
    {
        public string GetDeviceName()
        {
            return DeviceInfo.Model;
        }
    }
}
