﻿namespace MauiAppDemo
{
    public partial class MainPage : ContentPage
    {
        private readonly IMathService _mathService;
        private readonly ISemanticScreenReaderService _semanticScreenReaderServicem;
        int count = 0;

        public MainPage(IMathService mathService, ISemanticScreenReaderService semanticScreenReaderServicem)
        {
            _mathService = mathService;
            _semanticScreenReaderServicem = semanticScreenReaderServicem;
            InitializeComponent();
        }

        //public void Add(int a, int b)
        //{

        //}
        internal void OnCounterClicked(object sender, EventArgs e)
        {
            var result = _mathService.Add(1, 2);
            count++;
            count += (int)result;

            if (count == 1)
                CounterBtn.Text = $"Clicked {count} time";
            else
                CounterBtn.Text = $"Clicked {count} times";

            _semanticScreenReaderServicem.Announce(CounterBtn.Text);
        }
    }

    public interface ISemanticScreenReaderService
    {
        void Announce(string message);
    }

    internal class SemanticScreenReaderService : ISemanticScreenReaderService
    {
        public void Announce(string message)
        {
            SemanticScreenReader.Announce(message);

        }
    }
}
