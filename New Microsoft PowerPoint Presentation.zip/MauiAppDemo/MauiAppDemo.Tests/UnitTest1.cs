﻿using Moq;

namespace MauiAppDemo.Tests
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {
            MathService mathService = new MathService();
            var result = mathService.Add(1, 2);

            Assert.Equal(3, result);
        }

        [Fact]
        public void AddMethodShouldBeCalledWhenOnCounterClickedIsInvoked()
        {
            Mock<IMathService> mock = new Mock<IMathService>();
            Mock<ISemanticScreenReaderService> mockSemanticScreenReaderService = new Mock<ISemanticScreenReaderService>();
            mock.Setup(a => a.Add(It.IsAny<int>(), It.IsAny<int>())).Returns(3);

            MainPage mainPage = new MainPage(mock.Object, mockSemanticScreenReaderService.Object);
            mainPage.OnCounterClicked(null,null);

            mock.Verify(a => a.Add(It.IsAny<int>(), It.IsAny<int>()), Times.Once);

            //Assert.Equal(3, result);
        }
    }
}
